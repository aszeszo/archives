/* version information

  (c) 2007 (W3C) MIT, ERCIM, Keio University
  See tidy.h for the copyright notice.

  CVS Info :

    $Author: arnaud02 $ 
    $Date: 2007/03/21 16:12:06 $ 
    $Revision: 1.19 $ 

*/

static const char TY_(release_date)[] = "21 March 2007";
